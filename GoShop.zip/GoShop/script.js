function scrollToMusthave() {
    document.getElementById('musthave').scrollIntoView({
        behavior: 'smooth'
    });
}